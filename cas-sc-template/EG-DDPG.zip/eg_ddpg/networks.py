"""Network modules for EG-DDPG: bounded deterministic actor and Q critic."""
import torch
import torch.nn as nn

from config import TRAIN, STATE_DIM, ACTION_DIM


def mlp(sizes, activation=nn.ReLU, out_act=nn.Identity):
    layers = []
    for i in range(len(sizes) - 1):
        layers.append(nn.Linear(sizes[i], sizes[i + 1]))
        layers.append(activation() if i < len(sizes) - 2 else out_act())
    return nn.Sequential(*layers)


class DeterministicActor(nn.Module):
    """Maps state to a bounded action in [-1, 1] (then mapped to thickness)."""

    def __init__(self, state_dim=STATE_DIM, act_dim=ACTION_DIM, hidden=TRAIN.hidden_dim):
        super().__init__()
        self.net = mlp([state_dim, hidden, hidden, act_dim], out_act=nn.Tanh)

    def forward(self, state):
        return self.net(state)


class QCritic(nn.Module):
    def __init__(self, state_dim=STATE_DIM, act_dim=ACTION_DIM, hidden=TRAIN.hidden_dim):
        super().__init__()
        self.net = mlp([state_dim + act_dim, hidden, hidden, 1])

    def forward(self, state, action):
        return self.net(torch.cat([state, action], dim=-1)).squeeze(-1)
