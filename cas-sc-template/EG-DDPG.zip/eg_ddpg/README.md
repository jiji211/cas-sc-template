# EG-DDPG 复现项目（DDPG 替代 SAC 框架）

对应论文：*Path-conditioned slicing-toolpath coupled decision-making for 3D concrete
printing: Eulerian-graph-guided soft actor-critic optimization* 第 5.3.3 节的
**EG-DDPG 求解器**。本项目保持论文的路径条件化切片环境与欧拉图路径实现完全不变，
仅把策略优化器替换为 **Deep Deterministic Policy Gradient（确定性 actor-critic）**，
作为独立、自包含、可直接运行的完整项目。

## 1. 安装

```bash
pip install -r requirements.txt
```

## 2. 运行

```bash
# 训练（DDPG 为唯一算法）
python train.py --episodes 300 --seed 0

# 确定性推理：plan.json / plan.gcode / plan.png
python inference.py --model runs/eg_ddpg_seed0/model.pt --category topology
```

## 3. 模块与论文对应

| 文件 | 论文内容 |
|------|----------|
| `geometry.py` | 第 3 节五类结构，几何描述符 `g_t`，支持真实 STL |
| `euler_graph.py` | 点集提取、图 `G`/空走图 `H`、Eq.(8) 连通、Eq.(9) 匹配、Eq.(10) 起点、Eq.(11) Hierholzer |
| `rewards.py` | Eq.(12)–(27) 截面误差、效率、转弯、连续性与组合奖励 |
| `env.py` | Eq.(1)–(7) 状态/动作空间与可行动作集 `A_t` 投影 |
| `networks.py` | 确定性 actor（tanh）与 Q critic |
| `ddpg.py` | DDPG：目标网络、高斯探索噪声、critic/actor 更新与软更新 |
| `metrics.py` | 第 5.1 节六项指标 |
| `train.py` / `inference.py` | 训练循环与确定性推理、G 代码、路径图 |

## 4. DDPG 与原 SAC 的关键差异

- 策略为**确定性** `a = tanh(mu(s))`，训练时靠外加高斯噪声探索，而非 SAC 的随机策略+熵正则。
- 单个 critic（SAC 为双 Q 取最小），目标 `y = r + γ(1−d) Q_t(s', actor_t(s'))`。
- 无自动温度 `α`、无目标熵；其余环境、图、奖励、动作投影与 SAC 版本逐行一致，保证可比。

## 5. 参数来源

- 论文给定（`config.py` 标 PAPER）：`Dn=20mm`、层高 `11–14mm`（`ω1=0.55,ω2=0.70`）、
  奖励权重 `(0.2, 0.7, 0.1)`、`r_fail>1`。
- 论文未给的 DDPG 超参数（标 DDPG-DEFAULT）：`γ=0.99, τ=0.005, lr=1e-3, 256×256,
  batch=256, 噪声 std=0.1`，采用 Lillicrap et al.(2016) 体系常用值，可自行调整。

## 6. 复现边界

数据集论文声明 *on request*，本项目用参数化合成几何保证无外部数据即可跑通，并支持
`--stl your_part.stl`；材料流变与附录 A–D 不在该 PDF，G 代码为规划层示意。
