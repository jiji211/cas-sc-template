"""EG-DDPG training entry point (Algorithm 1 with the DDPG solver).

Example:
  python train.py --episodes 300 --seed 0
"""
import argparse
import json
import os
import numpy as np
import torch

from config import TRAIN
from geometry import ALL_CATEGORIES
from env import SlicingEnv
from ddpg import DDPGAgent
from metrics import evaluate


def set_seed(seed: int):
    np.random.seed(seed)
    torch.manual_seed(seed)


def deterministic_eval(agent, categories, seed):
    env = SlicingEnv(seed=seed + 1000)
    agg = []
    for cat in categories:
        s = env.reset(cat)
        done = False
        while not done:
            a = agent.act(s, deterministic=True)
            s, _, done, _ = env.step(a)
        agg.append(evaluate(env.history, env.geometry))
    keys = ["total_time_s", "effective_travel_ratio", "turns", "start_stop",
            "adjacent_area_diff", "volume_deviation_rate"]
    return {k: float(np.mean([m[k] for m in agg])) for k in keys}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--episodes", type=int, default=300)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--categories", default="all")
    ap.add_argument("--eval-every", type=int, default=50)
    ap.add_argument("--out", default="runs")
    args = ap.parse_args()

    set_seed(args.seed)
    TRAIN.seed = args.seed
    cats = ALL_CATEGORIES if args.categories == "all" else args.categories.split(",")
    out_dir = os.path.join(args.out, f"eg_ddpg_seed{args.seed}")
    os.makedirs(out_dir, exist_ok=True)

    agent = DDPGAgent()
    env = SlicingEnv(seed=args.seed)
    returns, eval_log = [], []
    global_steps = 0

    for ep in range(1, args.episodes + 1):
        cat = cats[np.random.randint(len(cats))]
        s = env.reset(cat)
        ep_r, done = 0.0, False
        while not done:
            a = agent.act(s)
            ns, r, done, info = env.step(a)
            agent.store(s, a, r, ns, float(done))
            s, ep_r, global_steps = ns, ep_r + r, global_steps + 1
            if global_steps >= TRAIN.update_after and global_steps % TRAIN.update_every == 0:
                agent.update()
        returns.append(ep_r)

        if ep % args.eval_every == 0 or ep == args.episodes:
            mean = deterministic_eval(agent, cats, args.seed)
            mean["episode"], mean["train_return"] = ep, ep_r
            eval_log.append(mean)
            print(f"ep {ep:4d} | trainR {ep_r:7.3f} | eval "
                  f"{json.dumps({k: round(v, 4) for k, v in mean.items() if k != 'episode'})}")

    agent.save(os.path.join(out_dir, "model.pt"))
    np.save(os.path.join(out_dir, "returns.npy"), np.array(returns))
    with open(os.path.join(out_dir, "eval.json"), "w") as f:
        json.dump(eval_log, f, indent=2)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.figure(figsize=(7, 4))
        x = np.arange(1, len(returns) + 1)
        plt.plot(x, returns, alpha=0.4, label="episode return")
        w = max(1, len(returns) // 30)
        plt.plot(x, np.convolve(returns, np.ones(w) / w, mode="same"), label=f"moving avg ({w})")
        plt.xlabel("Episode"); plt.ylabel("Return"); plt.legend(); plt.grid(alpha=0.3)
        plt.title(f"EG-DDPG training (seed {args.seed})")
        plt.tight_layout(); plt.savefig(os.path.join(out_dir, "curve.png"), dpi=130)
    except Exception as exc:
        print("plot skipped:", exc)
    print("saved to", out_dir)


if __name__ == "__main__":
    main()
