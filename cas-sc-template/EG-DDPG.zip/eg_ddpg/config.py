"""Global configuration for the EG-DDPG project.

Values explicitly reported in the paper are marked [PAPER]. Hyper-parameters
that the paper does not state are set to canonical DDPG (Lillicrap et al.,
2016) / common actor-critic defaults and are marked [DDPG-DEFAULT] so they
can be changed deliberately.
"""
from dataclasses import dataclass, field
import numpy as np


@dataclass
class ProcessConfig:
    # Nozzle and admissible layer-thickness interval [PAPER, Sec. 4.2.1 & 5.1]
    nozzle_diameter: float = 20.0          # Dn = 20 mm
    omega1: float = 0.55                   # h_min = omega1 * Dn
    omega2: float = 0.70                   # h_max = omega2 * Dn
    h_min: float = field(init=False)       # 11 mm
    h_max: float = field(init=False)       # 14 mm
    # Reward weights [PAPER, Sec. 5.1]: (lambda_sec, lambda_eff, lambda_qual)
    lambda_sec: float = 0.2
    lambda_eff: float = 0.7
    lambda_qual: float = 0.1
    # Quality mixing weight eta in Eq. (25); not stated in paper -> 0.5
    eta: float = 0.5
    # Failure penalty, paper requires r_fail > 1 (Eq. 26)
    r_fail: float = 2.0
    # Geometric resolution for point-set extraction (arc-length sampling)
    sample_interval: float = 5.0           # mm
    merge_tolerance: float = 1.0           # mm
    # Admissible idle connection range (geometric constraint on H_t)
    idle_max_length: float = 60.0          # mm
    # Nominal nozzle travel speed for converting length to execution time.
    # Not given in the PDF (calibration lives in Appendix B); used only for
    # reporting total time in seconds.
    print_speed: float = 50.0              # mm/s
    travel_speed: float = 100.0            # mm/s
    # A turn is counted when the printing-segment heading change exceeds this.
    turn_angle_deg: float = 30.0

    def __post_init__(self):
        self.h_min = self.omega1 * self.nozzle_diameter
        self.h_max = self.omega2 * self.nozzle_diameter
        assert abs(self.h_min - 11.0) < 1e-9
        assert abs(self.h_max - 14.0) < 1e-9
        s = self.lambda_sec + self.lambda_eff + self.lambda_qual
        assert abs(s - 1.0) < 1e-9


@dataclass
class TrainConfig:
    # Discount factor [DDPG-DEFAULT]; paper only requires gamma in (0, 1]
    gamma: float = 0.99
    # Soft target update coefficient (polyak averaging) [DDPG-DEFAULT]
    tau: float = 0.005
    actor_lr: float = 1e-3
    critic_lr: float = 1e-3
    hidden_dim: int = 256                  # two hidden layers [DDPG-DEFAULT]
    batch_size: int = 256
    replay_capacity: int = 1_000_000
    update_after: int = 256                # env steps before first update
    update_every: int = 1
    # Gaussian exploration noise std on the [-1, 1] action [DDPG-DEFAULT]
    policy_noise: float = 0.1
    seed: int = 0
    device: str = "cpu"


PROC = ProcessConfig()
TRAIN = TrainConfig()

# Fixed dimensionality of the geometric descriptor g_t in Eq. (4)
GEO_DIM = 12
# State = [g_t (GEO_DIM), z_t/H (1), x_end normalized xy (2)]
STATE_DIM = GEO_DIM + 3
ACTION_DIM = 1

# Normalization bounds for synthetic geometries
XY_NORM = 100.0
RHO_DEFAULT = 1.0e6                        # effectively flat wall, rho -> inf
