"""Configuration for the SAC-path-planning project.

Two stage-wise variants share the same SAC route learner and differ only in how
the layer set is produced before path realization:
  slicer="stl"     -> STL geometry-driven adaptive slicing chooses layer heights
  slicer="uniform" -> equal/average layer thickness
PAPER marks values reported in the paper; DEFAULT marks standard SAC values.
"""
from dataclasses import dataclass, field
import numpy as np


@dataclass
class ProcessConfig:
    nozzle_diameter: float = 20.0
    omega1: float = 0.55
    omega2: float = 0.70
    h_min: float = field(init=False)
    h_max: float = field(init=False)
    lambda_sec: float = 0.2
    lambda_eff: float = 0.7
    lambda_qual: float = 0.1
    eta: float = 0.5
    r_fail: float = 2.0
    sample_interval: float = 5.0
    merge_tolerance: float = 1.0
    idle_max_length: float = 60.0
    print_speed: float = 50.0
    travel_speed: float = 100.0
    turn_angle_deg: float = 30.0
    # Adaptive slicing stops increasing h once the sectional error (Eqs. 12-14)
    # reaches this normalized threshold; used only by slicer="stl".
    adaptive_error_target: float = 0.15

    def __post_init__(self):
        self.h_min = self.omega1 * self.nozzle_diameter
        self.h_max = self.omega2 * self.nozzle_diameter
        assert abs(self.h_min - 11.0) < 1e-9
        assert abs(self.h_max - 14.0) < 1e-9
        assert abs(self.lambda_sec + self.lambda_eff + self.lambda_qual - 1.0) < 1e-9


@dataclass
class TrainConfig:
    gamma: float = 0.99
    tau: float = 0.005
    actor_lr: float = 3e-4
    critic_lr: float = 3e-4
    alpha_lr: float = 3e-4
    hidden_dim: int = 256
    batch_size: int = 256
    replay_capacity: int = 1_000_000
    target_entropy: float = -3.0        # -action_dim for the 3-D route action
    init_alpha: float = 1.0
    update_after: int = 256
    update_every: int = 1
    seed: int = 0
    device: str = "cpu"


PROC = ProcessConfig()
TRAIN = TrainConfig()

GEO_DIM = 12
PATH_ACTION_DIM = 3
# route state = [g_t (12), z/H (1), h/H (1), previous end xy (2)]
PATH_STATE_DIM = GEO_DIM + 4
STATE_DIM = PATH_STATE_DIM
ACTION_DIM = PATH_ACTION_DIM
XY_NORM = 100.0
RHO_DEFAULT = 1.0e6
