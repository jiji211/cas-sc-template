"""Policy-controlled path realization: SAC route action -> executable path.

The continuous 3-D route action decides the degrees of freedom that the paper
notes can differ across Eulerian circuits (Sec. 4.2.2):
  action[0] start-vertex phase (which vertex begins the traversal)
  action[1] edge-order preference (min turning vs. maximize printing continuity)
  action[2] parity-matching tie-break direction
Connectivity (Eq. 8) and the structure of the Eulerian multigraph stay fixed.
"""
import numpy as np
import networkx as nx

from config import PROC
from euler_graph import point_set_extraction, _Edge, RealizedPath


def _fail(reason):
    return RealizedPath(np.zeros((0, 3)), np.zeros(0, dtype=bool), 0.0, -1, False, reason)


def build_with_policy(sec, prev_end, action) -> RealizedPath:
    extracted = point_set_extraction(sec)
    if extracted is None:
        return _fail("empty section")
    coords, ring_ids, _ = extracted
    n = len(coords)
    a0, a1, a2 = [float(x) for x in action]

    print_edges = []
    for ring in ring_ids:
        for j in range(len(ring)):
            u, v = ring[j], ring[(j + 1) % len(ring)]
            if u != v:
                print_edges.append((u, v))

    H = nx.Graph(); H.add_nodes_from(range(n))
    pair = {}
    for u, v in print_edges:
        w = float(np.linalg.norm(coords[u] - coords[v]))
        pair[(u, v)] = w
        if H.has_edge(u, v):
            H[u][v]["weight"] = min(H[u][v]["weight"], w)
        else:
            H.add_edge(u, v, weight=w)
    dmat = np.linalg.norm(coords[:, None, :] - coords[None, :, :], axis=2)
    iu, ju = np.where((dmat > 0) & (dmat <= PROC.idle_max_length))
    for u, v in zip(iu, ju):
        if u < v and not H.has_edge(int(u), int(v)):
            H.add_edge(int(u), int(v), weight=float(dmat[u, v]))

    G = nx.Graph(); G.add_nodes_from(range(n)); G.add_edges_from(print_edges)
    if not nx.is_connected(G):
        if not nx.is_connected(H):
            return _fail("idle graph cannot connect components")
        labels = {}
        for ci, comp in enumerate(nx.connected_components(G)):
            for v in comp:
                labels[v] = ci
        n_lab = len(set(labels.values()))
        cross = sorted((H[u][v]["weight"], u, v) for u, v in H.edges if labels[u] != labels[v])
        uf = list(range(n_lab)); extra = []

        def uf_find(x):
            while uf[x] != x:
                uf[x] = uf[uf[x]]; x = uf[x]
            return x

        for w, u, v in cross:
            ru, rv = uf_find(labels[u]), uf_find(labels[v])
            if ru != rv:
                uf[rv] = ru; extra.append((u, v, w))
                if len(extra) == n_lab - 1:
                    break
        if len(extra) < n_lab - 1:
            return _fail("cannot establish connectivity")
    else:
        extra = []

    instances = []; eid = 0
    for u, v in print_edges:
        instances.append(_Edge(u, v, pair[(u, v)], True, eid)); eid += 1
    for u, v, w in extra:
        instances.append(_Edge(u, v, w, False, eid)); eid += 1

    degree = np.zeros(n, dtype=int)
    for e in instances:
        degree[e.u] += 1; degree[e.v] += 1
    odd = [v for v in range(n) if degree[v] % 2 == 1]
    if odd:
        lengths = dict(nx.all_pairs_dijkstra_path_length(H, weight="weight"))
        paths = dict(nx.all_pairs_dijkstra_path(H, weight="weight"))
        odd_graph = nx.Graph()
        for i, u in enumerate(odd):
            for v in odd[i + 1:]:
                if v in lengths[u]:
                    # action[2] perturbs the matching weight (geometry-dependent)
                    pert = 0.1 * a2 * lengths[u][v] * ((u % 3) / 3.0)
                    odd_graph.add_edge(u, v, weight=lengths[u][v] + pert)
        if not nx.is_connected(odd_graph) or len(odd_graph) < len(odd):
            return _fail("odd vertices not matchable")
        for u, v in nx.min_weight_matching(odd_graph, weight="weight"):
            for x, y in zip(paths[u][v][:-1], paths[u][v][1:]):
                instances.append(_Edge(x, y, H[x][y]["weight"], False, eid)); eid += 1

    # action[0]: start-vertex phase
    start = int(np.clip((a0 + 1) / 2.0, 0.0, 0.9999) * n)
    entry_length = float(np.linalg.norm(coords[start] - prev_end))
    w2 = (a1 + 1) / 2.0

    adj = [[] for _ in range(n)]
    for e in instances:
        adj[e.u].append(e); adj[e.v].append(e)

    stack_v, stack_e, edge_circuit = [start], [], []
    incoming = {start: None}
    while stack_v:
        v = stack_v[-1]
        avail = [e for e in adj[v] if not e.used]
        if avail:
            inc = incoming.get(v)

            def cost(e):
                nxt = e.other(v)
                vec = coords[nxt] - coords[v]
                if inc is not None:
                    no = np.linalg.norm(inc) * np.linalg.norm(vec)
                    turn = np.arccos(np.clip(np.dot(inc, vec) / max(no, 1e-9), -1, 1)) / np.pi
                else:
                    turn = 0.0
                cont = 0.0 if e.printing else 1.0
                return w2 * turn + (1 - w2) * cont, e.eid

            _, chosen = min(((cost(e), e) for e in avail), key=lambda t: (t[0][0], t[0][1]))
            chosen.used = True
            nxt = chosen.other(v)
            incoming[nxt] = coords[nxt] - coords[v]
            stack_v.append(nxt); stack_e.append(chosen)
        else:
            if stack_e:
                edge_circuit.append(stack_e.pop())
            stack_v.pop()
    edge_circuit.reverse()
    if not edge_circuit or any(not e.used for e in instances):
        return _fail("policy traversal did not cover every edge")

    pts = [coords[start].copy()]; flags = []; cur = start
    for e in edge_circuit:
        nxt = e.other(cur)
        pts.append(coords[nxt].copy()); flags.append(e.printing); cur = nxt
    return RealizedPath(np.array(pts), np.array(flags, dtype=bool),
                        entry_length, start, True)
