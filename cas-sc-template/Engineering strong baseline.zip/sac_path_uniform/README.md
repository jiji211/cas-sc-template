# 平均分层 + SAC 选路径

对应论文：*Path-conditioned slicing-toolpath coupled decision-making for 3D concrete
printing*。本项目是与论文主框架（**SAC 选层高、欧拉图定路径**）角色互换的
**stage-wise（先定层、后选路）**方案：层高在路径学习前由**平均（均匀）分层**固定，
SAC 改为学习每层沉积路径，对应论文 1.1.2 / 表 1 的 *layer set precedes path
realization* 范式。

- **选层（无学习）**：`uniform_slicer.py` 将构件分 N 等份，平均层高尽量接近区间
  中点 12.5mm，各层等高。
- **选路（SAC）**：每个固定层高的截面由 SAC 动作控制路径。

## 1. 安装

```bash
pip install -r requirements.txt
```

## 2. 运行

```bash
python train.py --episodes 300
python inference.py --model runs/uniform_sacpath_seed0/model.pt --category topology
```

## 3. SAC 如何“选路径”（连续 3 维动作）

路径的连通（Eq.8）与欧拉多重图结构保持确定性，SAC 动作控制论文 4.2.2 指出的
“不同边序会得到不同 turns/start-stop”的自由度：

| 动作 | 含义 |
|---|---|
| `a[0]` 起点相位 | 在全部顶点中选择遍历起点（而非仅取最近点） |
| `a[1]` 边序偏好 | 在“最小转弯”与“优先连续打印”之间插值，决定 Hierholzer 在 junction 处选哪条边 |
| `a[2]` 匹配方向 | 对奇度最小权匹配（Eq.9）施加几何相关的 tie-break 扰动 |

状态为 `[g_t(12), z/H, h/H, 上一终点 xy(2)]` 共 16 维；奖励只用路径部分
（Eq.17–25 的效率与质量，权重按 0.7:0.1 重新归一），因为层高已固定。

## 4. 模块对应

| 文件 | 内容 |
|---|---|
| `uniform_slicer.py` | 平均（均匀）分层 |
| `path_builder.py` | 受 SAC 动作控制的起点、匹配与 Hierholzer 边选择 |
| `path_env.py` | 先定层、逐层 SAC 选路的 stage-wise 环境 |
| `path_sac.py` | 3 维动作的 SAC（双 critic、自动温度、软目标） |
| `geometry.py` / `euler_graph.py` / `rewards.py` / `metrics.py` | 几何、图、奖励与六项指标 |

## 5. 参数与边界

论文给定（PAPER）：`Dn=20mm`、层高 `11–14mm`、权重 `0.2/0.7/0.1`、`r_fail>1`；
SAC 学习率/网络结构等论文未给，取标准默认（见 `config.py`）。
无外部 STL 时用参数化几何即可跑通，并支持 `--stl your_part.stl`；材料流变与附录
A–D 不在该 PDF，G 代码为规划层示意。
