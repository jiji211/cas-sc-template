"""Equal/average layer-thickness slicer (fixed heights before routing).

The component is divided into N equal layers whose average thickness is as
close as possible to the midpoint of [h_min, h_max]; SAC then learns the route
on each fixed-height layer.
"""
from config import PROC


def plan_layers(geometry):
    h_mid = (PROC.h_min + PROC.h_max) / 2.0
    n_est = max(1, round(geometry.H / h_mid))

    # choose an N whose average height lies inside the admissible range
    candidates = [n_est - 1, n_est, n_est + 1, n_est + 2]
    N = n_est
    for n in candidates:
        if n >= 1 and PROC.h_min <= geometry.H / n <= PROC.h_max:
            N = n
            break
    h_avg = geometry.H / N

    layers = []
    z = 0.0
    for i in range(N):
        h = h_avg if i < N - 1 else geometry.H - z
        z = min(z + h, geometry.H)
        layers.append({"z": z, "h": h})
    return layers
