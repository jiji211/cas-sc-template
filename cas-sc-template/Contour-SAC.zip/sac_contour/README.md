# Contour-SAC：轮廓法替代图论路径

对应论文 5.3.2 节的路径实现消融。**SAC 仍学习连续层高（耦合框架不变）**，仅把
欧拉图路径实现（图论部分）替换为**轮廓法**，构成论文中的 **Contour-SAC**。

- **选层（SAC）**：策略输出连续层高，动作投影与可行性约束保持不变。
- **路径（轮廓法，固定模块）**：`contour_planner.py` 逐环把截面转为可执行路径。

## 1. 安装

```bash
pip install -r requirements.txt
```

## 2. 运行

```bash
python train.py --episodes 300
python inference.py --model runs/contour_sac_seed0/model.pt --category topology
```

## 3. 轮廓法路径器原理（`contour_planner.py`）

- 每个截面环作为独立闭合轮廓，沿环打印一圈，环内边为 printing。
- 环与环之间用停料空走连接，环序用“距当前喷嘴最近”的局部贪心。
- 不做图连通/奇度匹配，因此多环、带孔截面会产生显式空走与更多 start-stop，
  与论文中 Contour-SAC 中断次数更高的结论一致。
- 与欧拉实现共用同一接口 `realize(sec, prev_end) -> RealizedPath`，复用点集提取
  `Φ`（几何预处理，非图论）与 `RealizedPath` 数据结构，因此环境、奖励 Eq.12–27、
  SAC 更新 Eq.28–33、六项指标全部不变，保证消融只改变路径模块。

## 4. 参数与边界

论文给定（PAPER）：`Dn=20mm`、层高 `11–14mm`、权重 `0.2/0.7/0.1`、`r_fail>1`；
轮廓法的贪心规则论文未给细节，取常用默认（见模块顶部），可调。
无外部 STL 即可跑通，支持 `--stl your_part.stl`；材料流变与附录 A–D 不在该 PDF。
