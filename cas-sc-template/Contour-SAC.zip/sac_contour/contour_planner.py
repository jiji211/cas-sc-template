"""Contour-based path realization (replaces the graph-theory route module).

Each section loop is printed as a closed contour one at a time; loops are linked
by non-printing transfers using a nearest (greedy) loop order. There is no graph
connectivity or odd-degree matching, so disconnected/multi-loop sections simply
incur explicit idle moves and more start-stop events. Same interface as the
Eulerian realize(): realize(sec, prev_end) -> RealizedPath.
"""
import numpy as np

from euler_graph import point_set_extraction, RealizedPath


def _fail(reason):
    return RealizedPath(np.zeros((0, 3)), np.zeros(0, dtype=bool), 0.0, -1, False, reason)


def _nearest_index(coords, ring, pos):
    d = [np.linalg.norm(coords[idx] - pos) for idx in ring]
    return int(np.argmin(d))


def realize(sec, prev_end):
    extracted = point_set_extraction(sec)
    if extracted is None:
        return _fail("empty section")
    coords, ring_ids, _ = extracted
    if not ring_ids:
        return _fail("no contour loops")

    remaining = list(range(len(ring_ids)))
    cur = prev_end.copy()
    pts, flags = [], []
    entry_length = 0.0
    first = True

    while remaining:
        # greedy nearest loop and nearest start vertex on it
        cand = []
        for li in remaining:
            ring = ring_ids[li]
            loc = _nearest_index(coords, ring, cur)
            vidx = ring[loc]
            cand.append((float(np.linalg.norm(coords[vidx] - cur)), li, loc))
        _, li, loc = min(cand, key=lambda t: t[0])
        ring = ring_ids[li]
        k = len(ring)

        # idle transfer into this contour (entry on the first loop, internal otherwise)
        start_vidx = ring[loc]
        move = float(np.linalg.norm(coords[start_vidx] - cur))
        if first:
            entry_length = move
            pts.append(coords[start_vidx].copy())
            first = False
        else:
            pts.append(coords[start_vidx].copy())
            flags.append(False)

        # one closed printing pass around the contour
        for j in range(1, k + 1):
            vidx = ring[(loc + j) % k]
            pts.append(coords[vidx].copy())
            flags.append(True)
        cur = coords[start_vidx]
        remaining.remove(li)

    return RealizedPath(np.array(pts), np.array(flags, dtype=bool),
                        entry_length, 0, True)
