"""Stage-wise environment: STL-adaptive heights fixed first, SAC learns routes.

On reset the whole layer set is produced by the adaptive (geometry-driven)
slicer, then at every fixed-height layer the SAC route action is realized
through path_builder and rewarded by path efficiency/quality only (Eqs. 17-25).
"""
import numpy as np

from config import PROC, PATH_STATE_DIM, XY_NORM
from geometry import build_geometry, ALL_CATEGORIES
import adaptive_slicer
from path_builder import build_with_policy
from rewards import efficiency_cost, quality_cost


class PathPlanningEnv:
    def __init__(self, seed=0):
        self.rng = np.random.default_rng(seed)
        self.geometry = None
        self.layers = []
        self.idx = 0
        self.z = 0.0
        self.prev_end = np.zeros(3)
        self.history = []
        # re-normalized path-only reward weights
        s = PROC.lambda_eff + PROC.lambda_qual
        self.w_eff = PROC.lambda_eff / s
        self.w_qual = PROC.lambda_qual / s

    @property
    def state_dim(self):
        return PATH_STATE_DIM

    @property
    def action_dim(self):
        return 3

    def reset(self, category=None, geometry=None):
        if geometry is not None:
            self.geometry = geometry
        else:
            cat = category if category is not None else self.rng.choice(ALL_CATEGORIES)
            self.geometry = build_geometry(cat, self.rng)
        self.layers = adaptive_slicer.plan_layers(self.geometry)
        self.idx, self.z = 0, 0.0
        self.prev_end = np.array([0.0, -50.0, 0.0])
        self.history = []
        return self._state()

    def _state(self):
        h = self.layers[self.idx]["h"]
        g = self.geometry.descriptor(self.z)
        head = np.array([self.z / self.geometry.H, h / self.geometry.H])
        end = self.prev_end[:2] / XY_NORM
        return np.concatenate([g, head, end]).astype(np.float32)

    def step(self, action):
        layer = self.layers[self.idx]
        h, z_new = layer["h"], layer["z"]
        sec = self.geometry.section(z_new)
        path = build_with_policy(sec, self.prev_end, action)

        if not path.feasible:
            reward, done = -PROC.r_fail, True
        else:
            c_eff, c_qual = efficiency_cost(path), quality_cost(path)
            reward = -(self.w_eff * c_eff + self.w_qual * c_qual)
            done = self.idx == len(self.layers) - 1
            self.prev_end = np.array([path.points[0, 0], path.points[0, 1], z_new])

        info = {"h": h, "z": z_new, "feasible": path.feasible,
                "path": path, "sec": sec, "area": self.geometry.area(z_new)}
        self.history.append(info)
        self.z, self.idx = z_new, self.idx + 1
        next_state = self._state() if not done else np.zeros(PATH_STATE_DIM, dtype=np.float32)
        return next_state, float(reward), done, info
