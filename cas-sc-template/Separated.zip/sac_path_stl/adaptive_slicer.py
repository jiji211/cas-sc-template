"""STL geometry-driven adaptive slicer (chooses layer heights before routing).

The layer set is determined purely from geometry: pick the largest admissible
h in [h_min, h_max] whose normalized sectional approximation error
(Eqs. 12-14) stays below a target, while keeping the residual partitionable.
No reinforcement learning is used here; SAC only learns the route afterwards.
"""
import numpy as np

from config import PROC
from rewards import sectional_error

S_REF = PROC.h_max ** 2 / 2.0


def _feasible_intervals(R):
    out = []
    m = 0
    while m * PROC.h_min <= R + 1e-9:
        lo = max(PROC.h_min, R - m * PROC.h_max)
        hi = min(PROC.h_max, R - m * PROC.h_min)
        if lo <= hi + 1e-9:
            out.append((lo, hi))
        m += 1
    return out


def _project(h_cand, R):
    if R <= PROC.h_max + 1e-9:
        return R
    best, best_d = h_cand, float("inf")
    for lo, hi in _feasible_intervals(R):
        h = float(np.clip(h_cand, lo, hi))
        if abs(h - h_cand) < best_d:
            best, best_d = h, abs(h - h_cand)
    return best


def _normalized_error(geometry, z, h):
    z_new = min(z + h, geometry.H)
    sec = geometry.section(z_new)
    return sectional_error(h, sec.theta, sec.rho, sec.gamma) / S_REF


def plan_layers(geometry):
    """Return a stage-wise list of {z, h} via adaptive geometry slicing."""
    layers = []
    z = 0.0
    while z < geometry.H - 1e-9:
        R = geometry.H - z
        if R <= PROC.h_max + 1e-9:
            h = R
        else:
            h = PROC.h_max
            grid = np.linspace(PROC.h_max, PROC.h_min, 12)
            for cand in grid:
                cand = _project(cand, R)
                if _normalized_error(geometry, z, cand) <= PROC.adaptive_error_target:
                    h = cand
                    break
            else:
                h = _project(PROC.h_min, R)
        z = min(z + h, geometry.H)
        layers.append({"z": z, "h": h})
    return layers
