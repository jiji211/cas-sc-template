"""EG-PPO: on-policy clipped proximal policy optimization under the coupled env."""
import numpy as np
import torch
import torch.nn.functional as F

from config import TRAIN, STATE_DIM
from networks import GaussianActor, mlp


class ValueNet(torch.nn.Module):
    def __init__(self, state_dim=STATE_DIM, hidden=TRAIN.hidden_dim):
        super().__init__()
        self.net = mlp([state_dim, hidden, hidden, 1])

    def forward(self, state):
        return self.net(state).squeeze(-1)


class PPOAgent:
    name = "EG-PPO"

    def __init__(self, cfg=TRAIN, state_dim=STATE_DIM):
        self.cfg = cfg
        self.device = torch.device(cfg.device)
        self.actor = GaussianActor(state_dim=state_dim).to(self.device)
        self.value = ValueNet(state_dim).to(self.device)
        self.opt = torch.optim.Adam(list(self.actor.parameters()) + list(self.value.parameters()),
                                    lr=cfg.actor_lr)
        self._clear()

    def _clear(self):
        for k in ("s", "a", "logp", "v", "r", "ns", "d"):
            setattr(self, k, [])

    def act(self, state, deterministic=False):
        s = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            a = self.actor.deterministic(s) if deterministic else self.actor.sample(s)[0]
        return float(a.item())

    def collect_step(self, state, action, reward, next_state, done):
        s = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        a_t = torch.tensor([[action]], dtype=torch.float32, device=self.device)
        with torch.no_grad():
            logp, _ = self.actor.log_prob(s, a_t)
            v = self.value(s)
        self.s.append(state); self.a.append([action]); self.logp.append(float(logp.item()))
        self.v.append(float(v.item())); self.r.append(reward)
        self.ns.append(next_state); self.d.append(float(done))

    def _gae(self):
        n = len(self.r)
        adv = np.zeros(n, dtype=np.float32)
        gae = 0.0
        for t in reversed(range(n)):
            if self.d[t]:
                next_v = 0.0
            else:
                next_v = float(self.value(torch.as_tensor(
                    self.ns[t], dtype=torch.float32, device=self.device).unsqueeze(0)).item())
            delta = self.r[t] + self.cfg.gamma * next_v - self.v[t]
            gae = delta + self.cfg.gamma * self.cfg.gae_lambda * (1 - self.d[t]) * gae
            adv[t] = gae
        return adv, adv + np.array(self.v, dtype=np.float32)

    def update(self):
        if len(self.r) < self.cfg.minibatch:
            return None
        adv, ret = self._gae()
        s = torch.as_tensor(np.array(self.s), dtype=torch.float32, device=self.device)
        a = torch.as_tensor(np.array(self.a), dtype=torch.float32, device=self.device)
        old_logp = torch.as_tensor(np.array(self.logp), dtype=torch.float32, device=self.device)
        adv_t = torch.as_tensor(adv, dtype=torch.float32, device=self.device)
        adv_t = (adv_t - adv_t.mean()) / (adv_t.std() + 1e-8)
        ret_t = torch.as_tensor(ret, dtype=torch.float32, device=self.device)

        n, stats = len(self.r), {}
        for _ in range(self.cfg.epochs):
            idx = np.random.permutation(n)
            for start in range(0, n, self.cfg.minibatch):
                mb = idx[start:start + self.cfg.minibatch]
                logp, ent = self.actor.log_prob(s[mb], a[mb])
                ratio = torch.exp(logp - old_logp[mb])
                surr1 = ratio * adv_t[mb]
                surr2 = torch.clamp(ratio, 1 - self.cfg.clip_ratio,
                                    1 + self.cfg.clip_ratio) * adv_t[mb]
                policy_loss = -torch.min(surr1, surr2).mean()
                value_loss = F.mse_loss(self.value(s[mb]), ret_t[mb])
                loss = policy_loss + self.cfg.value_coef * value_loss - self.cfg.entropy_coef * ent.mean()
                self.opt.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.actor.parameters(), self.cfg.max_grad_norm)
                self.opt.step()
                stats = {"policy_loss": float(policy_loss.item()),
                         "value_loss": float(value_loss.item())}
        self._clear()
        return stats

    def save(self, path):
        torch.save({"actor": self.actor.state_dict(), "value": self.value.state_dict()}, path)

    def load(self, path):
        ckpt = torch.load(path, map_location=self.device)
        self.actor.load_state_dict(ckpt["actor"])
        self.value.load_state_dict(ckpt["value"])
