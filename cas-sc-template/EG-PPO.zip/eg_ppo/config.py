"""Global configuration for the EG-PPO project.

Values explicitly reported in the paper are marked [PAPER]. Hyper-parameters
that the paper does not state are set to canonical clipped-PPO (Schulman et al.,
2017) defaults and are marked [PPO-DEFAULT] so they can be changed deliberately.
"""
from dataclasses import dataclass, field
import numpy as np


@dataclass
class ProcessConfig:
    nozzle_diameter: float = 20.0
    omega1: float = 0.55
    omega2: float = 0.70
    h_min: float = field(init=False)
    h_max: float = field(init=False)
    lambda_sec: float = 0.2
    lambda_eff: float = 0.7
    lambda_qual: float = 0.1
    eta: float = 0.5
    r_fail: float = 2.0
    sample_interval: float = 5.0
    merge_tolerance: float = 1.0
    idle_max_length: float = 60.0
    print_speed: float = 50.0
    travel_speed: float = 100.0
    turn_angle_deg: float = 30.0

    def __post_init__(self):
        self.h_min = self.omega1 * self.nozzle_diameter
        self.h_max = self.omega2 * self.nozzle_diameter
        assert abs(self.h_min - 11.0) < 1e-9
        assert abs(self.h_max - 14.0) < 1e-9
        assert abs(self.lambda_sec + self.lambda_eff + self.lambda_qual - 1.0) < 1e-9


@dataclass
class TrainConfig:
    gamma: float = 0.99                    # [PPO-DEFAULT]
    actor_lr: float = 3e-4
    critic_lr: float = 3e-4
    hidden_dim: int = 256                  # two hidden layers [PPO-DEFAULT]
    clip_ratio: float = 0.2                # PPO policy clip [PPO-DEFAULT]
    epochs: int = 10                       # optimization epochs per update
    minibatch: int = 64
    gae_lambda: float = 0.95               # GAE trace decay [PPO-DEFAULT]
    value_coef: float = 0.5
    entropy_coef: float = 0.01
    max_grad_norm: float = 0.5
    seed: int = 0
    device: str = "cpu"


PROC = ProcessConfig()
TRAIN = TrainConfig()

GEO_DIM = 12
STATE_DIM = GEO_DIM + 3
ACTION_DIM = 1
XY_NORM = 100.0
RHO_DEFAULT = 1.0e6
