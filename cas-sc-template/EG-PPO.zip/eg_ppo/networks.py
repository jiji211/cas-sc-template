"""Network module for EG-PPO: tanh-squashed Gaussian stochastic policy."""
import torch
import torch.nn as nn

from config import TRAIN, STATE_DIM, ACTION_DIM

LOG_STD_MIN, LOG_STD_MAX = -20.0, 2.0


def mlp(sizes, activation=nn.ReLU, out_act=nn.Identity):
    layers = []
    for i in range(len(sizes) - 1):
        layers.append(nn.Linear(sizes[i], sizes[i + 1]))
        layers.append(activation() if i < len(sizes) - 2 else out_act())
    return nn.Sequential(*layers)


class GaussianActor(nn.Module):
    """Tanh-squashed Gaussian policy used by PPO."""

    def __init__(self, state_dim=STATE_DIM, act_dim=ACTION_DIM, hidden=TRAIN.hidden_dim):
        super().__init__()
        self.trunk = mlp([state_dim, hidden, hidden], out_act=nn.ReLU)
        self.mean = nn.Linear(hidden, act_dim)
        self.log_std = nn.Linear(hidden, act_dim)

    def _distribution(self, state):
        h = self.trunk(state)
        mu = self.mean(h)
        log_std = torch.clamp(self.log_std(h), LOG_STD_MIN, LOG_STD_MAX)
        return mu, log_std.exp()

    def sample(self, state):
        mu, std = self._distribution(state)
        normal = torch.distributions.Normal(mu, std)
        pre = normal.rsample()
        action = torch.tanh(pre)
        logp = normal.log_prob(pre).sum(-1)
        logp -= torch.log(1.0 - action.pow(2) + 1e-6).sum(-1)
        return action, logp

    def log_prob(self, state, action):
        mu, std = self._distribution(state)
        normal = torch.distributions.Normal(mu, std)
        pre = torch.atanh(torch.clamp(action, -1 + 1e-6, 1 - 1e-6))
        logp = normal.log_prob(pre).sum(-1)
        logp -= torch.log(1.0 - action.pow(2) + 1e-6).sum(-1)
        return logp, normal.entropy().sum(-1)

    def deterministic(self, state):
        mu, _ = self._distribution(state)
        return torch.tanh(mu)
