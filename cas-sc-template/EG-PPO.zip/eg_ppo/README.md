# EG-PPO 复现项目（PPO 替代 SAC 框架）

对应论文：*Path-conditioned slicing-toolpath coupled decision-making for 3D concrete
printing: Eulerian-graph-guided soft actor-critic optimization* 第 5.3.3 节的
**EG-PPO 求解器**。路径条件化切片环境与欧拉图路径实现保持不变，仅把策略优化器替换为
**Proximal Policy Optimization（带 GAE 的 clip 式 on-policy 策略梯度）**，
为独立、自包含、可直接运行的完整项目。

## 1. 安装

```bash
pip install -r requirements.txt
```

## 2. 运行

```bash
python train.py --episodes 300 --seed 0
python inference.py --model runs/eg_ppo_seed0/model.pt --category topology
```

## 3. 模块与论文对应

| 文件 | 论文内容 |
|------|----------|
| `geometry.py` | 第 3 节五类结构，几何描述符 `g_t`，支持 STL |
| `euler_graph.py` | 点集提取、图 `G`/空走图 `H`、Eq.(8)–(11) |
| `rewards.py` | Eq.(12)–(27) 全部奖励 |
| `env.py` | Eq.(1)–(7) 状态/动作与可行动作集投影 |
| `networks.py` | tanh-Gaussian 随机策略 |
| `ppo.py` | GAE、clip 策略损失、价值网络、多 epoch 小批量更新 |
| `metrics.py` | 第 5.1 节六项指标 |
| `train.py` / `inference.py` | 训练、确定性推理、G 代码、路径图 |

## 4. PPO 与原 SAC 的关键差异

- **on-policy**：只用当前策略采集的轨迹更新，更新后丢弃 rollout；无 replay buffer、无目标 Q 网络。
- 用独立价值网络 `V(s)` 配合 GAE 估计优势，策略损失为 clip 概率比形式，而非 SAC 的软 Bellman。
- 探索靠随机策略本身的分布与熵奖励，没有自动温度 `α`；环境、图、奖励、动作投影逐行一致。

## 5. 参数来源

- 论文给定（PAPER）：`Dn=20mm`、层高 `11–14mm`、权重 `(0.2,0.7,0.1)`、`r_fail>1`。
- 论文未给（PPO-DEFAULT，Schulman et al. 2017 常用值）：`γ=0.99, clip=0.2, epochs=10,
  minibatch=64, GAE λ=0.95, lr=3e-4, 256×256`，可在 `config.py` 调整。

## 6. 复现边界

数据集 *on request*，用参数化合成几何保证无外部数据即可跑通，支持 `--stl your_part.stl`；
材料流变与附录 A–D 不在该 PDF，G 代码为规划层示意。
