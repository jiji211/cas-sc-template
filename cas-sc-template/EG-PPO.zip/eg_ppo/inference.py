"""EG-PPO deterministic inference: metrics, G-code and a path plot.

Examples:
  python inference.py --model runs/eg_ppo_seed0/model.pt --category topology
  python inference.py --model runs/eg_ppo_seed0/model.pt --stl part.stl
"""
import argparse
import json
import os
import numpy as np

from config import PROC
from env import SlicingEnv
from geometry import STLGeometry, build_geometry
from ppo import PPOAgent
from metrics import evaluate


def write_gcode(history, path_out, extrusion_per_mm=0.05):
    lines = ["; EG-PPO plan G-code", "G28", "G92 E0", "G1 F%.1f" % (PROC.print_speed * 60)]
    e_total = 0.0
    for info in history:
        path = info["path"]
        z = info["z"]
        start = path.points[0]
        lines.append(f"G0 Z{z + 5:.2f}")
        lines.append(f"G0 X{start[0]:.2f} Y{start[1]:.2f}")
        lines.append(f"G0 Z{z:.2f}")
        for i in range(len(path.flags)):
            p = path.points[i + 1]
            seg_len = float(np.linalg.norm(path.points[i + 1] - path.points[i]))
            if path.flags[i]:
                e_total += seg_len * extrusion_per_mm
                lines.append(f"G1 X{p[0]:.2f} Y{p[1]:.2f} E{e_total:.3f}")
            else:
                lines.append(f"G0 X{p[0]:.2f} Y{p[1]:.2f}")
    with open(path_out, "w") as f:
        f.write("\n".join(lines))


def plot_plan(history, path_out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 7))
    for info in history:
        p = info["path"].points
        flags = info["path"].flags
        for i in range(len(flags)):
            seg = p[i:i + 2]
            ax.plot(seg[:, 0], seg[:, 1], color="#1f5fbf" if flags[i] else "#d1495b",
                    lw=1.4 if flags[i] else 0.9)
        ax.plot([p[0, 0]], [p[0, 1]], "ko", ms=3)
    ax.set_aspect("equal"); ax.grid(alpha=0.3)
    ax.set_title("EG-PPO plan: blue = printing, red = idle/transfer")
    plt.tight_layout(); plt.savefig(path_out, dpi=140)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--category", default="topology")
    ap.add_argument("--stl", default=None)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="plan_out")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    agent = PPOAgent()
    agent.load(args.model)
    env = SlicingEnv(seed=args.seed)

    if args.stl:
        s = env.reset(geometry=STLGeometry(args.stl))
    else:
        s = env.reset(geometry=build_geometry(args.category, np.random.default_rng(args.seed)))

    done = False
    while not done:
        s, _, done, info = env.step(agent.act(s, deterministic=True))

    metrics = evaluate(env.history, env.geometry)
    plan = [{"layer": i + 1, "h_mm": round(info["h"], 3), "z_mm": round(info["z"], 3),
             "n_points": len(info["path"].points)} for i, info in enumerate(env.history)]
    with open(os.path.join(args.out, "plan.json"), "w") as f:
        json.dump({"metrics": metrics, "layers": plan}, f, indent=2)
    write_gcode(env.history, os.path.join(args.out, "plan.gcode"))
    plot_plan(env.history, os.path.join(args.out, "plan.png"))
    print(json.dumps(metrics, indent=2))
    print("outputs in", args.out)


if __name__ == "__main__":
    main()
