"""Coupled slicing environment with the genetic-algorithm path module (GA-SAC).

The SAC policy learns the continuous layer height; the section is turned into
an executable path by the fixed genetic-algorithm realization (ga_planner).
"""
import numpy as np

from config import PROC, STATE_DIM, XY_NORM
from geometry import build_geometry, ALL_CATEGORIES
from rewards import compute_reward
from ga_planner import realize


def feasible_intervals(R):
    out = []
    m = 0
    while m * PROC.h_min <= R + 1e-9:
        lo = max(PROC.h_min, R - m * PROC.h_max)
        hi = min(PROC.h_max, R - m * PROC.h_min)
        if lo <= hi + 1e-9:
            out.append((lo, hi))
        m += 1
    return out


def project_action(h_cand, R):
    if R <= PROC.h_max + 1e-9:
        return R
    best, best_d = h_cand, float("inf")
    for lo, hi in feasible_intervals(R):
        h = float(np.clip(h_cand, lo, hi))
        if abs(h - h_cand) < best_d:
            best, best_d = h, abs(h - h_cand)
    return best


def denorm_action(a):
    return PROC.h_min + (float(np.clip(a, -1, 1)) + 1) / 2 * (PROC.h_max - PROC.h_min)


class SlicingEnv:
    def __init__(self, seed=0):
        self._realize = realize
        self.rng = np.random.default_rng(seed)
        self.geometry = None
        self.z = 0.0
        self.prev_end = np.zeros(3)
        self.t = 0
        self.history = []

    @property
    def state_dim(self):
        return STATE_DIM

    def reset(self, category=None, geometry=None):
        if geometry is not None:
            self.geometry = geometry
        else:
            cat = category if category is not None else self.rng.choice(ALL_CATEGORIES)
            self.geometry = build_geometry(cat, self.rng)
        self.z, self.t = 0.0, 0
        self.prev_end = np.array([0.0, -50.0, 0.0])
        self.history = []
        return self._state()

    def _state(self):
        g = self.geometry.descriptor(self.z)
        progress = np.array([self.z / self.geometry.H])
        end = self.prev_end[:2] / XY_NORM
        return np.concatenate([g, progress, end]).astype(np.float32)

    def step(self, norm_action):
        R = self.geometry.H - self.z
        h = project_action(denorm_action(norm_action), R)
        z_new = min(self.z + h, self.geometry.H)
        sec = self.geometry.section(z_new)
        path = self._realize(sec, self.prev_end)

        if not path.feasible:
            reward, done = -PROC.r_fail, True
        else:
            reward = compute_reward(h, sec, path)
            done = z_new >= self.geometry.H - 1e-9
            self.prev_end = np.array([path.points[0, 0], path.points[0, 1], z_new])

        info = {"h": h, "z": z_new, "feasible": path.feasible,
                "path": path, "sec": sec, "area": self.geometry.area(z_new)}
        self.history.append(info)
        self.z, self.t = z_new, self.t + 1
        next_state = self._state() if not done else np.zeros(STATE_DIM, dtype=np.float32)
        return next_state, float(reward), done, info
