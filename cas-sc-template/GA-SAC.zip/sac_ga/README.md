# GA-SAC：遗传算法替代图论路径

对应论文 5.3.2 节的路径实现消融。**SAC 仍学习连续层高（耦合框架不变）**，仅把
欧拉图路径实现（图论部分）替换为**遗传算法**，构成论文中的 **GA-SAC**。

- **选层（SAC）**：策略输出连续层高，动作投影与可行性约束保持不变。
- **路径（GA，固定模块）**：`ga_planner.py` 用遗传算法把截面转为可执行路径。

## 1. 安装

```bash
pip install -r requirements.txt
```

## 2. 运行

```bash
python train.py --episodes 300
python inference.py --model runs/ga_sac_seed0/model.pt --category topology
```

## 3. 遗传算法路径器原理（`ga_planner.py`）

- 染色体 = 环顺序的排列（环内打印路径固定，GA 只优化环序即总空走）。
- 种群注入一个贪心个体；锦标赛选择（k=3）、OX 顺序交叉、swap 交换变异，迭代取最优。
- 适应度为 entry + 环间空走总长度，越短越好；环数少时自动减少代数以保证速度。
- 与欧拉实现共用同一接口 `realize(sec, prev_end) -> RealizedPath`，复用点集提取
  `Φ`（几何预处理，非图论）与 `RealizedPath` 数据结构，因此环境、奖励 Eq.12–27、
  SAC 更新 Eq.28–33、六项指标全部不变，保证消融只改变路径模块。

## 4. 参数与边界

论文给定（PAPER）：`Dn=20mm`、层高 `11–14mm`、权重 `0.2/0.7/0.1`、`r_fail>1`；
GA 种群/代数/变异率论文未给细节，取常用默认（见模块顶部），可调。
无外部 STL 即可跑通，支持 `--stl your_part.stl`；材料流变与附录 A–D 不在该 PDF。
