"""Genetic-algorithm path realization (replaces the graph-theory route module).

A chromosome is a permutation of the section loops (the printing pass inside
each loop is fixed; the GA optimizes the loop order, hence the total idle
transfer). It uses tournament selection, order-crossover (OX) and swap
mutation, seeded with a greedy individual. Same interface: realize(sec, prev).
"""
import numpy as np

from euler_graph import point_set_extraction, RealizedPath

POP_SIZE = 40
MUT_PROB = 0.25
TOURNAMENT = 3


def _fail(reason):
    return RealizedPath(np.zeros((0, 3)), np.zeros(0, dtype=bool), 0.0, -1, False, reason)


def _nearest(coords, ring, pos):
    d = [np.linalg.norm(coords[i] - pos) for i in ring]
    return int(np.argmin(d))


def _idle_cost(order, coords, ring_ids, start_pos):
    cur = start_pos.copy()
    total = 0.0
    for li in order:
        loc = _nearest(coords, ring_ids[li], cur)
        vidx = ring_ids[li][loc]
        total += float(np.linalg.norm(coords[vidx] - cur))
        cur = coords[vidx]
    return total


def _greedy_order(n, coords, ring_ids, start_pos):
    order, cur, remaining = [], start_pos.copy(), list(range(n))
    while remaining:
        best = min(remaining, key=lambda li: float(np.linalg.norm(
            coords[ring_ids[li][_nearest(coords, ring_ids[li], cur)]] - cur)))
        order.append(best)
        cur = coords[ring_ids[best][_nearest(coords, ring_ids[best], cur)]]
        remaining.remove(best)
    return order


def _ox(p1, p2, rng):
    n = len(p1)
    a, b = sorted(rng.choice(n, 2, replace=False))
    child = [None] * n
    child[a:b] = p1[a:b]
    segment = set(p1[a:b])
    fill = [x for x in p2 if x not in segment]
    slots = [i for i in range(n) if child[i] is None]
    for slot, val in zip(slots, fill):
        child[slot] = val
    return child


def _mutate(chrom, rng):
    if rng.random() < MUT_PROB:
        i, j = rng.choice(len(chrom), 2, replace=False)
        chrom[i], chrom[j] = chrom[j], chrom[i]
    return chrom


def _expand(order, coords, ring_ids, prev_end):
    cur = prev_end.copy()
    pts, flags, entry, first = [], [], 0.0, True
    for li in order:
        ring = ring_ids[li]
        loc = _nearest(coords, ring, cur)
        start_vidx = ring[loc]
        move = float(np.linalg.norm(coords[start_vidx] - cur))
        if first:
            entry = move; first = False
        else:
            flags.append(False)
        pts.append(coords[start_vidx].copy())
        for j in range(1, len(ring) + 1):
            pts.append(coords[ring[(loc + j) % len(ring)]].copy())
            flags.append(True)
        cur = coords[start_vidx]
    return RealizedPath(np.array(pts), np.array(flags, dtype=bool), entry, 0, True)


def realize(sec, prev_end):
    extracted = point_set_extraction(sec)
    if extracted is None:
        return _fail("empty section")
    coords, ring_ids, _ = extracted
    n = len(ring_ids)
    if n == 0:
        return _fail("no contour loops")
    if n == 1:
        return _expand([0], coords, ring_ids, prev_end)

    rng = np.random.default_rng()
    gens = 25 if n <= 2 else 80
    population = [np.random.permutation(n).tolist() for _ in range(POP_SIZE - 1)]
    population.append(_greedy_order(n, coords, ring_ids, prev_end))

    def tournament():
        group = [population[i] for i in rng.choice(len(population), TOURNAMENT, replace=False)]
        return min(group, key=lambda o: _idle_cost(o, coords, ring_ids, prev_end))

    for _ in range(gens):
        new_pop = [min(population, key=lambda o: _idle_cost(o, coords, ring_ids, prev_end))]
        while len(new_pop) < POP_SIZE:
            child = _ox(tournament(), tournament(), rng)
            new_pop.append(_mutate(child, rng))
        population = new_pop

    best = min(population, key=lambda o: _idle_cost(o, coords, ring_ids, prev_end))
    return _expand(best, coords, ring_ids, prev_end)
