"""Six evaluation metrics used in Sec. 5.1 over a completed plan."""
import math
import numpy as np

from config import PROC


def _turns(path) -> int:
    pts, flags = path.points, path.flags
    seg = pts[1:] - pts[:-1]
    norms = np.linalg.norm(seg, axis=1)
    thr = math.radians(PROC.turn_angle_deg)
    count = 0
    for i in range(1, len(seg)):
        if flags[i - 1] and flags[i] and norms[i] > 1e-9 and norms[i - 1] > 1e-9:
            c = float(np.dot(seg[i - 1], seg[i]) / (norms[i - 1] * norms[i]))
            if math.acos(float(np.clip(c, -1, 1))) > thr:
                count += 1
    return count


def _start_stops(path, is_first: bool) -> int:
    switches = sum(int(path.flags[i] != path.flags[i - 1]) for i in range(1, len(path.flags)))
    return switches + (1 if is_first else 0)


def evaluate(history, geometry) -> dict:
    total_print, total_travel, time_s = 0.0, 0.0, 0.0
    turns, start_stops = 0, 0
    areas, heights = [], []
    for i, info in enumerate(history):
        path = info["path"]
        lp = path.l_print
        lt = path.entry_length + path.l_travel_internal
        total_print += lp
        total_travel += lt
        time_s += lp / PROC.print_speed + lt / PROC.travel_speed
        turns += _turns(path)
        start_stops += _start_stops(path, i == 0)
        areas.append(info["area"])
        heights.append(info["h"])

    areas = np.array(areas)
    heights = np.array(heights)
    area_diff = float(np.mean(np.abs(np.diff(areas)))) if len(areas) > 1 else 0.0

    # target volume by fine-grained ground-truth area integration
    fine = np.linspace(0, geometry.H, 200)
    target_v = float(np.trapezoid(np.array([geometry.area(z) for z in fine]), fine))
    plan_v = float(np.sum(areas * heights))
    vol_dev = abs(plan_v - target_v) / max(abs(target_v), 1e-9)

    return {
        "total_time_s": time_s,
        "effective_travel_ratio": total_print / max(total_print + total_travel, 1e-9),
        "turns": turns,
        "start_stop": start_stops,
        "adjacent_area_diff": area_diff,
        "volume_deviation_rate": vol_dev,
        "n_layers": len(history),
    }
