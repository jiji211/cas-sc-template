"""EG-DDPG baseline: deterministic actor-critic under the same coupled env."""
import copy
import numpy as np
import torch
import torch.nn.functional as F

from config import TRAIN, STATE_DIM, ACTION_DIM
from networks import DeterministicActor, QCritic
from replay_buffer import ReplayBuffer


class DDPGAgent:
    name = "EG-DDPG"

    def __init__(self, cfg=TRAIN, state_dim=STATE_DIM, action_dim=ACTION_DIM):
        self.cfg = cfg
        self.device = torch.device(cfg.device)
        self.actor = DeterministicActor(state_dim, action_dim, cfg.hidden_dim).to(self.device)
        self.actor_t = copy.deepcopy(self.actor)
        self.critic = QCritic(state_dim, action_dim, cfg.hidden_dim).to(self.device)
        self.critic_t = copy.deepcopy(self.critic)
        self.actor_opt = torch.optim.Adam(self.actor.parameters(), lr=cfg.actor_lr)
        self.critic_opt = torch.optim.Adam(self.critic.parameters(), lr=cfg.critic_lr)
        self.buffer = ReplayBuffer(cfg.replay_capacity, state_dim, action_dim, cfg.device)

    def store(self, s, a, r, ns, d):
        self.buffer.add(s, np.array([a], dtype=np.float32), r, ns, d)

    def act(self, state, deterministic=False):
        s = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            a = float(self.actor(s).item())
        if not deterministic:
            a += np.random.normal(0.0, self.cfg.policy_noise)
        return float(np.clip(a, -1.0, 1.0))

    def update(self):
        s, a, r, ns, d = self.buffer.sample(self.cfg.batch_size)
        with torch.no_grad():
            a_next = self.actor_t(ns)
            y = r + self.cfg.gamma * (1.0 - d) * self.critic_t(ns, a_next)
        critic_loss = F.mse_loss(self.critic(s, a), y)
        self.critic_opt.zero_grad()
        critic_loss.backward()
        self.critic_opt.step()

        actor_loss = -self.critic(s, self.actor(s)).mean()
        self.actor_opt.zero_grad()
        actor_loss.backward()
        self.actor_opt.step()

        tau = self.cfg.tau
        with torch.no_grad():
            for p, pt in zip(self.actor.parameters(), self.actor_t.parameters()):
                pt.mul_(1 - tau).add_(tau * p)
            for p, pt in zip(self.critic.parameters(), self.critic_t.parameters()):
                pt.mul_(1 - tau).add_(tau * p)
        return {"critic_loss": float(critic_loss.item()), "actor_loss": float(actor_loss.item())}

    def save(self, path: str):
        torch.save({"actor": self.actor.state_dict()}, path)

    def load(self, path: str):
        self.actor.load_state_dict(torch.load(path, map_location=self.device)["actor"])
