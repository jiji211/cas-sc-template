# EG-SAC 复现项目

对应论文：*Path-conditioned slicing-toolpath coupled decision-making for 3D concrete
printing: Eulerian-graph-guided soft actor-critic optimization*。

本项目把论文第 4 节的公式与 Algorithm 1 实现为可直接运行的 Python 代码，覆盖
**路径条件化切片环境、欧拉图路径实现、EG-SAC 以及 EG-DDPG / EG-PPO 基线、
六项评估指标、G 代码导出**。

## 1. 安装

```bash
pip install -r requirements.txt
```

## 2. 快速开始

```bash
# 训练 EG-SAC（Algorithm 1），300 个 episode
python train.py --agent sac --episodes 300 --seed 0

# 基线
python train.py --agent ddpg --episodes 300
python train.py --agent ppo  --episodes 300

# 确定性推理：导出 plan.json / plan.gcode / plan.png
python inference.py --agent sac --model runs/sac_seed0/model.pt --category topology
```

输出目录 `runs/<agent>_seed<seed>/` 含 `model.pt`、`returns.npy`、`eval.json`、`curve.png`。

## 3. 模块与论文公式对应

| 文件 | 论文内容 |
|------|----------|
| `geometry.py` | 第 3 节五类结构（solid/hollow/freeform/overhang/topology），几何描述符 `g_t`，支持真实 STL |
| `euler_graph.py` | 点集提取 `Φ`、图 `G`、空走图 `H`、Eq.(8) 连通、Eq.(9) 奇度最小权完美匹配、Eq.(10) 起点、Eq.(11) Hierholzer |
| `rewards.py` | Eq.(12)–(27)：截面误差、效率、转弯、连续性与组合奖励 |
| `env.py` | Eq.(1)–(7)：状态/动作空间、可行动作集 `A_t` 投影、耦合闭环 |
| `networks.py` | tanh-Gaussian 随机策略、确定性策略、双 Q 网络 |
| `sac.py` | Eq.(28)–(33)：双 critic、自动温度、软目标更新 |
| `ddpg.py` / `ppo.py` | 同一耦合环境与同一欧拉实现下的 EG-DDPG / EG-PPO |
| `metrics.py` | 第 5.1 节六项指标 |
| `inference.py` | 确定性推理、G 代码与多层路径图 |

## 4. 参数来源说明（严谨性）

**论文明确给定（`config.py` 标记 PAPER）**

- 喷嘴 `Dn = 20 mm`；层高区间 `11–14 mm`，即 `ω1=0.55, ω2=0.70`（第 4.2.1、5.1 节）
- 奖励权重 `(λ_sec, λ_eff, λ_qual) = (0.2, 0.7, 0.1)`（第 5.1 节）
- 失败惩罚要求 `r_fail > 1`；动作一维，目标熵取 `-1`
- 论文用 6 个独立随机种子；心形件 8 层、层高约 12.4–12.5 mm

**论文未在正文给出、采用 SAC 原始文献（Haarnoja et al., 2018）标准默认值（标记 SAC-DEFAULT）**

- `γ=0.99, τ=0.005, lr=3e-4`、隐藏层 `256×256`、`batch=256`、缓冲 `1e6`
- `η=0.5`（Eq.25 的质量混合权重论文未给）
- 打印/空走速度、转弯判定角度用于把长度换算为秒与计数，论文附录 B 不在本 PDF 中，
  已在 `config.py` 暴露为可改参数

## 5. 关于数据集

论文数据集为 1050 个 STL，且声明 *Data will be made available on request*，本 PDF 未附带。
为保证无外部数据也能完整跑通，`geometry.py` 用参数化程序生成与论文五类结构一一对应的
构件（种子可控、带随机扰动）；同时 `STLGeometry` 支持加载你自己的 STL：

```bash
python inference.py --agent sac --model runs/sac_seed0/model.pt --stl your_part.stl
```

截面误差项 Eq.(12)–(14) 中的 `θ、ρ、γ` 对合成构件由几何解析给出；对 STL 可在
`STLGeometry` 构造时显式传入，或按需替换为表面估计。

## 6. 复现边界

本复现严格对应论文的**几何/路径规划与策略学习部分**。材料流变、挤出动力学、物理打印与
标定（附录 A–D）不在该 PDF 内，未纳入代码；G 代码为规划层示意，实际机床需按厂商
指令格式与标定的层高-命令映射调整。
