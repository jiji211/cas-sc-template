"""Path-conditioned slicing-toolpath coupling environment (Eqs. 1-7)."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict, Any

import numpy as np

from config import PROC, STATE_DIM, XY_NORM
from geometry import BaseGeometry, build_geometry, ALL_CATEGORIES
from euler_graph import realize, RealizedPath
from rewards import compute_reward


def feasible_intervals(R: float) -> list:
    """Closed intervals of h in [h_min, h_max] satisfying Eq. (6) for residual R."""
    out = []
    m = 0
    while m * PROC.h_min <= R + 1e-9:
        lo = max(PROC.h_min, R - m * PROC.h_max)
        hi = min(PROC.h_max, R - m * PROC.h_min)
        if lo <= hi + 1e-9:
            out.append((lo, hi))
        m += 1
    return out


def project_action(h_cand: float, R: float) -> float:
    """Project a candidate thickness onto the admissible set A_t (Eq. 6)."""
    if R <= PROC.h_max + 1e-9:
        return R  # final layer reaches the top (m = 0)
    intervals = feasible_intervals(R)
    best, best_d = h_cand, float("inf")
    for lo, hi in intervals:
        h = float(np.clip(h_cand, lo, hi))
        d = abs(h - h_cand)
        if d < best_d:
            best, best_d = h, d
    return best


def denorm_action(a: float) -> float:
    """Map a network output in [-1, 1] to the nominal thickness range."""
    a = float(np.clip(a, -1.0, 1.0))
    return PROC.h_min + (a + 1.0) / 2.0 * (PROC.h_max - PROC.h_min)


class SlicingEnv:
    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.geometry: Optional[BaseGeometry] = None
        self.z = 0.0
        self.prev_end = np.zeros(3)
        self.t = 0
        self.history = []

    @property
    def state_dim(self) -> int:
        return STATE_DIM

    def reset(self, category: Optional[str] = None, geometry: Optional[BaseGeometry] = None) -> np.ndarray:
        if geometry is not None:
            self.geometry = geometry
        else:
            cat = category if category is not None else self.rng.choice(ALL_CATEGORIES)
            self.geometry = build_geometry(cat, self.rng)
        self.z = 0.0
        self.t = 0
        self.prev_end = np.array([0.0, -50.0, 0.0])
        self.history = []
        return self._state()

    def _state(self) -> np.ndarray:
        g = self.geometry.descriptor(self.z)
        progress = np.array([self.z / self.geometry.H])
        end = self.prev_end[:2] / XY_NORM
        return np.concatenate([g, progress, end]).astype(np.float32)

    def step(self, norm_action: float) -> tuple:
        R = self.geometry.H - self.z
        h_nom = denorm_action(norm_action)
        h = project_action(h_nom, R)
        z_new = min(self.z + h, self.geometry.H)
        sec = self.geometry.section(z_new)
        path = realize(sec, self.prev_end)

        if not path.feasible:
            reward, done = -PROC.r_fail, True
        else:
            reward = compute_reward(h, sec, path)
            done = z_new >= self.geometry.H - 1e-9
            self.prev_end = np.array([path.points[0, 0], path.points[0, 1], z_new])

        info = {"h": h, "z": z_new, "feasible": path.feasible,
                "path": path, "sec": sec, "area": self.geometry.area(z_new)}
        self.history.append(info)
        self.z, self.t = z_new, self.t + 1
        next_state = self._state() if not done else np.zeros(STATE_DIM, dtype=np.float32)
        return next_state, float(reward), done, info
