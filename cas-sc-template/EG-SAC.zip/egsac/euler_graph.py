"""Eulerian-graph-guided toolpath realization (Sec. 4.2.2).

Implements: point-set extraction, deposition graph G, idle graph H,
minimum-idle connectivity (Eq. 8), odd-degree minimum-weight perfect matching
(Eq. 9), start-vertex selection (Eq. 10), and Hierholzer traversal (Eq. 11).
"""
from __future__ import annotations
import numpy as np
import networkx as nx
from dataclasses import dataclass
from typing import List, Tuple

from config import PROC
from geometry import Section


class _Edge:
    __slots__ = ("u", "v", "length", "printing", "eid", "used")

    def __init__(self, u: int, v: int, length: float, printing: bool, eid: int):
        self.u, self.v = u, v
        self.length, self.printing, self.eid = length, printing, eid
        self.used = False

    def other(self, x: int) -> int:
        return self.v if x == self.u else self.u


@dataclass
class RealizedPath:
    points: np.ndarray
    flags: np.ndarray
    entry_length: float
    start_index: int
    feasible: bool = True
    reason: str = ""

    @property
    def l_print(self) -> float:
        return float(sum(
            np.linalg.norm(self.points[i + 1] - self.points[i])
            for i in range(len(self.flags)) if self.flags[i]))

    @property
    def l_travel_internal(self) -> float:
        return float(sum(
            np.linalg.norm(self.points[i + 1] - self.points[i])
            for i in range(len(self.flags)) if not self.flags[i]))


def _merge_points(rings3: List[np.ndarray], tol: float) -> Tuple[np.ndarray, List[List[int]]]:
    all_pts = np.vstack(rings3)
    n = len(all_pts)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    d = np.linalg.norm(all_pts[:, None, :] - all_pts[None, :, :], axis=2)
    iu, ju = np.where(d < tol)
    for a, b in zip(iu, ju):
        if a < b:
            union(int(a), int(b))
    roots = {}
    for i in range(n):
        r = find(i)
        if r not in roots:
            roots[r] = len(roots)
    clusters = {}
    for i in range(n):
        clusters.setdefault(roots[find(i)], []).append(i)
    glob = np.array([all_pts[m].mean(axis=0) for m in clusters.values()])
    ring_ids, offset = [], 0
    for r3 in rings3:
        k = len(r3)
        ring_ids.append([roots[find(offset + j)] for j in range(k)])
        offset += k
    return glob, ring_ids


def point_set_extraction(sec: Section) -> Tuple[np.ndarray, List[List[int]], List[int]]:
    """Phi(C_t): sampled rings -> merged point set X_t; None when empty."""
    rings3 = []
    for r in sec.rings:
        if r.shape[1] == 2:
            r3 = np.column_stack([r, np.zeros(len(r))])
        else:
            r3 = r
        rings3.append(r3)
    if not rings3:
        return None
    coords, ring_ids = _merge_points(rings3, PROC.merge_tolerance)
    return coords, ring_ids, list(sec.component_ids)


def _fail(reason: str) -> RealizedPath:
    return RealizedPath(np.zeros((0, 3)), np.zeros(0, dtype=bool),
                        0.0, -1, False, reason)


def realize(sec: Section, prev_end: np.ndarray) -> RealizedPath:
    """Full Ct -> executable P_t pipeline."""
    extracted = point_set_extraction(sec)
    if extracted is None:
        return _fail("empty section")
    coords, ring_ids, _ = extracted
    n = len(coords)

    print_edges: List[Tuple[int, int]] = []
    for ring in ring_ids:
        k = len(ring)
        for j in range(k):
            a, b = ring[j], ring[(j + 1) % k]
            if a != b:
                print_edges.append((a, b))

    H = nx.Graph()
    H.add_nodes_from(range(n))
    pair = {}
    for a, b in print_edges:
        w = float(np.linalg.norm(coords[a] - coords[b]))
        pair[(a, b)] = w
        if H.has_edge(a, b):
            H[a][b]["weight"] = min(H[a][b]["weight"], w)
        else:
            H.add_edge(a, b, weight=w)
    dmat = np.linalg.norm(coords[:, None, :] - coords[None, :, :], axis=2)
    iu, ju = np.where((dmat > 0) & (dmat <= PROC.idle_max_length))
    for a, b in zip(iu, ju):
        if a < b and not H.has_edge(int(a), int(b)):
            H.add_edge(int(a), int(b), weight=float(dmat[a, b]))

    G = nx.Graph()
    G.add_nodes_from(range(n))
    G.add_edges_from(print_edges)
    if not nx.is_connected(G):
        if not nx.is_connected(H):
            return _fail("idle graph cannot connect components")
        comp_label = {}
        for ci, comp in enumerate(nx.connected_components(G)):
            for v in comp:
                comp_label[v] = ci
        labels = set(comp_label.values())
        cross = sorted((H[a][b]["weight"], a, b) for a, b in H.edges
                       if comp_label[a] != comp_label[b])
        uf = list(range(len(labels)))
        extra_edges = []

        def uf_find(x):
            while uf[x] != x:
                uf[x] = uf[uf[x]]
                x = uf[x]
            return x

        for w, a, b in cross:
            ra, rb = uf_find(comp_label[a]), uf_find(comp_label[b])
            if ra != rb:
                uf[rb] = ra
                extra_edges.append((a, b, w))
                if len(extra_edges) == len(labels) - 1:
                    break
        if len(extra_edges) < len(labels) - 1:
            return _fail("cannot establish connectivity")
    else:
        extra_edges = []

    instances: List[_Edge] = []
    eid = 0
    for a, b in print_edges:
        instances.append(_Edge(a, b, pair[(a, b)], True, eid))
        eid += 1
    for a, b, w in extra_edges:
        instances.append(_Edge(a, b, w, False, eid))
        eid += 1

    degree = np.zeros(n, dtype=int)
    for e in instances:
        degree[e.u] += 1
        degree[e.v] += 1
    odd = [v for v in range(n) if degree[v] % 2 == 1]
    if odd:
        lengths = dict(nx.all_pairs_dijkstra_path_length(H, weight="weight"))
        paths = dict(nx.all_pairs_dijkstra_path(H, weight="weight"))
        odd_graph = nx.Graph()
        for i, u in enumerate(odd):
            for v in odd[i + 1:]:
                if v in lengths[u]:
                    odd_graph.add_edge(u, v, weight=lengths[u][v])
        if not nx.is_connected(odd_graph) or len(odd_graph) < len(odd):
            return _fail("odd vertices not matchable")
        for u, v in nx.min_weight_matching(odd_graph, weight="weight"):
            for a, b in zip(paths[u][v][:-1], paths[u][v][1:]):
                instances.append(_Edge(a, b, H[a][b]["weight"], False, eid))
                eid += 1

    start = min(range(n), key=lambda v: float(np.linalg.norm(coords[v] - prev_end)))
    entry_length = float(np.linalg.norm(coords[start] - prev_end))

    adj: List[List[_Edge]] = [[] for _ in range(n)]
    for e in instances:
        adj[e.u].append(e)
        adj[e.v].append(e)
    stack_v, stack_e, edge_circuit = [start], [], []
    while stack_v:
        v = stack_v[-1]
        chosen = None
        while adj[v]:
            cand = adj[v].pop()
            if not cand.used:
                chosen = cand
                break
        if chosen is not None:
            chosen.used = True
            stack_v.append(chosen.other(v))
            stack_e.append(chosen)
        else:
            if stack_e:
                edge_circuit.append(stack_e.pop())
            stack_v.pop()
    edge_circuit.reverse()
    if not edge_circuit or any(not e.used for e in instances):
        return _fail("hierholzer did not cover every edge")

    pts = [coords[start].copy()]
    flags = []
    cur = start
    for e in edge_circuit:
        nxt = e.other(cur)
        pts.append(coords[nxt].copy())
        flags.append(e.printing)
        cur = nxt
    return RealizedPath(np.array(pts), np.array(flags, dtype=bool),
                        entry_length, start, True)
