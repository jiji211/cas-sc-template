"""Path-conditioned reward (Sec. 4.2.3, Eqs. 12-27)."""
from __future__ import annotations
import math
import numpy as np

from config import PROC
from geometry import Section
from euler_graph import RealizedPath


def sectional_error(h: float, theta: float, rho: float, gamma: int) -> float:
    """Eqs. (12)-(15): interlayer sectional approximation error S_t."""
    tan_theta = math.tan(theta)
    s1 = h ** 2 / (2.0 * tan_theta) if tan_theta > 1e-12 else 0.0
    sin_theta = math.sin(theta)
    if rho < 1e9 and sin_theta > 1e-9:
        x = 1.0 - h ** 2 / (2.0 * rho ** 2 * sin_theta ** 2)
        alpha = math.acos(float(np.clip(x, -1.0, 1.0)))
        s2 = rho ** 2 / 2.0 * (alpha - math.sin(alpha))
    else:
        s2 = 0.0
    return s1 + ((-1) ** gamma) * s2


def efficiency_cost(path: RealizedPath) -> float:
    """Eqs. (17)-(19): normalized non-printing motion fraction."""
    l_print, l_travel = path.l_print, path.entry_length + path.l_travel_internal
    total = l_print + l_travel
    return l_travel / total if total > 1e-12 else 0.0


def turning_cost(path: RealizedPath) -> float:
    """Eqs. (20)-(23): mean heading change over consecutive printing segments."""
    pts, flags = path.points, path.flags
    seg = pts[1:] - pts[:-1]
    norms = np.linalg.norm(seg, axis=1)
    angles = []
    for i in range(1, len(seg)):
        if flags[i - 1] and flags[i] and norms[i] > 1e-9 and norms[i - 1] > 1e-9:
            c = float(np.dot(seg[i - 1], seg[i]) / (norms[i - 1] * norms[i]))
            angles.append(math.acos(float(np.clip(c, -1.0, 1.0))))
    if not angles:
        return 0.0
    return float(np.sum(angles) / (math.pi * len(angles)))


def continuity_cost(path: RealizedPath) -> float:
    """Eq. (24): normalized printing/non-printing state switches."""
    flags = path.flags
    m = len(path.points)
    if m < 3:
        return 0.0
    switches = sum(int(flags[i] != flags[i - 1]) for i in range(1, len(flags)))
    return switches / max(1, m - 2)


def quality_cost(path: RealizedPath) -> float:
    """Eq. (25)."""
    return PROC.eta * turning_cost(path) + (1.0 - PROC.eta) * continuity_cost(path)


# Reference scale making the geometric penalty dimensionless and comparable
# with the other [0, 1] costs: S1 at the most adverse 45-degree inclination.
S_REF = None


def compute_reward(h: float, sec: Section, path: RealizedPath) -> float:
    """Eq. (26)-(27). Failure is handled by the environment via r_fail."""
    global S_REF
    if S_REF is None:
        S_REF = PROC.h_max ** 2 / 2.0
    c_sec = float(np.clip(sectional_error(h, sec.theta, sec.rho, sec.gamma) / S_REF, 0.0, 1.0))
    c_eff = efficiency_cost(path)
    c_qual = quality_cost(path)
    return -(PROC.lambda_sec * c_sec + PROC.lambda_eff * c_eff + PROC.lambda_qual * c_qual)
