"""Task-oriented geometry dataset.

Synthetic parametric components cover the five structural regimes of the paper
(Sec. 3.1): low-complexity solid, hollow, high-curvature free-form, overhang,
and topology-mutation. Each component exposes horizontal section contours,
local surface parameters for the sectional-error term, and the fixed-length
geometric descriptor g_t of Eq. (4). Real STL components can be loaded too.
"""
from __future__ import annotations
import math
import numpy as np
from dataclasses import dataclass
from typing import List, Dict, Any

from config import PROC, GEO_DIM, XY_NORM, RHO_DEFAULT

try:
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    _HAS_SHAPELY = True
except Exception:  # pragma: no cover
    _HAS_SHAPELY = False


def _circle(cx: float, cy: float, r: float, interval: float) -> np.ndarray:
    n = max(8, int(round(2 * math.pi * r / interval)))
    a = np.linspace(0.0, 2 * math.pi, n, endpoint=False)
    return np.column_stack([cx + r * np.cos(a), cy + r * np.sin(a)])


def _ellipse(cx: float, cy: float, rx: float, ry: float, interval: float) -> np.ndarray:
    n = max(8, int(round(math.pi * (3 * (rx + ry) - math.sqrt((3 * rx + ry) * (rx + 3 * ry))) / interval)))
    a = np.linspace(0.0, 2 * math.pi, n, endpoint=False)
    return np.column_stack([cx + rx * np.cos(a), cy + ry * np.sin(a)])


def _rect(cx: float, cy: float, w: float, h: float) -> np.ndarray:
    return np.array([[cx - w / 2, cy - h / 2], [cx + w / 2, cy - h / 2],
                     [cx + w / 2, cy + h / 2], [cx - w / 2, cy + h / 2]])


@dataclass
class Section:
    rings: List[np.ndarray]          # each ring is an open (non-repeated) Nx2 loop
    component_ids: List[int]         # physical component membership per ring
    theta: float                     # surface inclination angle, rad
    rho: float                       # curvature radius, mm
    gamma: int                       # 0 convex, 1 concave

    def to_3d(self, z: float) -> List[np.ndarray]:
        return [np.column_stack([r, np.full(len(r), z)]) for r in self.rings]


class BaseGeometry:
    category = "base"

    def __init__(self, H: float, rng: np.random.Generator):
        self.H = H
        self.rng = rng
        self.base_area = self.area(0.0)

    # ---- to be implemented by subclasses ----
    def section(self, z: float) -> Section:
        raise NotImplementedError

    # ---- shared utilities ----
    def _theta_from_rate(self, dr: float) -> float:
        # tan(theta) = dz / |dr|; vertical wall -> pi/2
        if abs(dr) < 1e-9:
            return math.pi / 2
        return math.atan(1.0 / abs(dr))

    def area(self, z: float) -> float:
        sec = self.section(z)
        if not _HAS_SHAPELY:
            return float(sum(0.5 * abs(np.dot(r[:, 0], np.roll(r[:, 1], 1)) -
                                       np.dot(r[:, 1], np.roll(r[:, 0], 1))) for r in sec.rings))
        polys = [Polygon(r).buffer(0) for r in sec.rings]
        total = unary_union(polys)
        return float(total.area)

    def perimeter(self, z: float) -> float:
        sec = self.section(z)
        return float(sum(np.linalg.norm(np.roll(r, -1, axis=0) - r, axis=1).sum() for r in sec.rings))

    def descriptor(self, z: float) -> np.ndarray:
        """Fixed-length GEO_DIM geometric descriptor g_t (all normalized)."""
        sec = self.section(z)
        pts = np.vstack(sec.rings)
        mins, maxs = pts.min(axis=0), pts.max(axis=0)
        centroid = pts.mean(axis=0)
        area = self.area(z)
        perim = self.perimeter(z)
        n_holes = max(0, len(sec.rings) - 1)
        rate = 0.0 if sec.theta >= math.pi / 2 - 1e-9 else 1.0 / math.tan(sec.theta)
        g = np.array([
            len(sec.rings) / 5.0,
            area / (XY_NORM ** 2),
            perim / (4 * XY_NORM),
            (maxs[0] - mins[0]) / XY_NORM,
            (maxs[1] - mins[1]) / XY_NORM,
            centroid[0] / XY_NORM,
            centroid[1] / XY_NORM,
            sec.theta / (math.pi / 2),
            min(1.0, RHO_DEFAULT / max(sec.rho, 1e-6)),
            area / max(self.base_area, 1e-9),
            n_holes / 5.0,
            float(np.clip(rate, 0.0, 2.0)),
        ], dtype=np.float64)
        assert len(g) == GEO_DIM
        return np.clip(g, -5.0, 5.0)


class SolidGeometry(BaseGeometry):
    """Low-complexity solid: nearly constant extruded section."""
    category = "solid"

    def __init__(self, rng: np.random.Generator):
        H = float(rng.uniform(90, 130))
        self.w = float(rng.uniform(45, 70))
        self.d = float(rng.uniform(45, 70))
        super().__init__(H, rng)

    def section(self, z: float) -> Section:
        ring = _rect(0.0, 0.0, self.w, self.d)
        return Section([ring], [0], math.pi / 2, RHO_DEFAULT, 0)


class HollowGeometry(BaseGeometry):
    """Hollow component with a systematic inward offset and an inner hole."""
    category = "hollow"

    def __init__(self, rng: np.random.Generator):
        H = float(rng.uniform(90, 130))
        self.r0 = float(rng.uniform(32, 42))
        self.hole0 = float(rng.uniform(14, 20))
        self.shrink = float(rng.uniform(6, 12))     # total inward reduction
        super().__init__(H, rng)

    def _radii(self, z: float):
        u = z / self.H
        outer = self.r0 - self.shrink * u
        hole = self.hole0 - self.shrink * 0.4 * u
        return outer, hole

    def section(self, z: float) -> Section:
        outer, hole = self._radii(z)
        rings = [_circle(0, 0, outer, PROC.sample_interval),
                 _circle(0, 0, max(hole, 6), PROC.sample_interval)]
        dr = -self.shrink / self.H
        theta = self._theta_from_rate(dr)
        return Section(rings, [0, 0], theta, RHO_DEFAULT, 1)


class FreeFormGeometry(BaseGeometry):
    """High-curvature free-form circular ornament whose radius oscillates."""
    category = "freeform"

    def __init__(self, rng: np.random.Generator):
        H = float(rng.uniform(90, 130))
        self.r0 = float(rng.uniform(26, 34))
        self.amp = float(rng.uniform(4, 9))
        self.periods = float(rng.choice([1.5, 2.0, 2.5]))
        super().__init__(H, rng)

    def _radius(self, z: float) -> float:
        return self.r0 + self.amp * math.sin(2 * math.pi * self.periods * z / self.H)

    def section(self, z: float) -> Section:
        r = self._radius(z)
        rings = [_circle(0, 0, r, PROC.sample_interval)]
        dr = (self._radius(min(z + 1, self.H)) - self._radius(max(z - 1, 0))) / 2.0
        theta = self._theta_from_rate(dr)
        # finite curvature radius derived from the radial oscillation
        rho = max(20.0, self.r0 ** 2 / max(self.amp, 1.0))
        gamma = 0 if dr >= 0 else 1
        return Section(rings, [0], theta, rho, gamma)


class OverhangGeometry(BaseGeometry):
    """Overhanging wall-like block: progressive lateral shift and expansion."""
    category = "overhang"

    def __init__(self, rng: np.random.Generator):
        H = float(rng.uniform(90, 130))
        self.w0 = float(rng.uniform(40, 55))
        self.shift = float(rng.uniform(15, 28))
        self.grow = float(rng.uniform(8, 16))
        super().__init__(H, rng)

    def section(self, z: float) -> Section:
        u = z / self.H
        cx = self.shift * u
        w = self.w0 + self.grow * u
        ring = _rect(cx, 0.0, w, w * 0.8)
        dr = self.grow / self.H
        theta = self._theta_from_rate(dr)
        return Section([ring], [0], theta, RHO_DEFAULT, 0)


class TopologyMutationGeometry(BaseGeometry):
    """Heart-shaped planter: two separated branches merge into one loop."""
    category = "topology"

    def __init__(self, rng: np.random.Generator):
        H = float(rng.uniform(95, 105))
        self.merge_z = H * float(rng.uniform(0.45, 0.55))
        self.branch_r = float(rng.uniform(10, 14))
        self.top_r = float(rng.uniform(26, 32))
        super().__init__(H, rng)

    def section(self, z: float) -> Section:
        if z < self.merge_z:
            u = z / max(self.merge_z, 1e-9)
            gap = 22 * (1 - u)
            rings = [_ellipse(-gap / 2, 0, self.branch_r, self.branch_r * 1.2, PROC.sample_interval),
                     _ellipse(gap / 2, 0, self.branch_r, self.branch_r * 1.2, PROC.sample_interval)]
            return Section(rings, [0, 1], math.pi / 2, RHO_DEFAULT, 0)
        u = (z - self.merge_z) / max(self.H - self.merge_z, 1e-9)
        r = self.branch_r * 2 + (self.top_r - self.branch_r * 2) * u
        rings = [_circle(0, 0, r, PROC.sample_interval)]
        dr = (self.top_r - self.branch_r * 2) / max(self.H - self.merge_z, 1e-9)
        return Section(rings, [0], self._theta_from_rate(dr), 80.0, 0)


class STLGeometry(BaseGeometry):
    """Section wrapper around a real STL mesh (horizontal planar slicing)."""
    category = "stl"

    def __init__(self, stl_path: str, theta: float = math.pi / 2,
                 rho: float = RHO_DEFAULT, gamma: int = 0):
        import trimesh
        self.mesh = trimesh.load(stl_path, force="mesh")
        self._theta, self._rho, self._gamma = theta, rho, gamma
        H = float(self.mesh.bounds[1, 2] - self.mesh.bounds[0, 2])
        super().__init__(H, np.random.default_rng(0))
        self.z0 = float(self.mesh.bounds[0, 2])

    def section(self, z: float) -> Section:
        import trimesh
        plane_origin = [0, 0, self.z0 + z]
        try:
            sliced = self.mesh.section(plane_origin=plane_origin, plane_normal=[0, 0, 1])
            if sliced is None:
                return Section([], [], self._theta, self._rho, self._gamma)
            planar, _ = sliced.to_planar()
            rings = [np.asarray(e.points)[:, :2] for e in planar.entities]
        except Exception:
            rings = []
        cids = list(range(len(rings)))
        return Section(rings, cids, self._theta, self._rho, self._gamma)


def build_geometry(category: str, rng: np.random.Generator) -> BaseGeometry:
    table = {
        "solid": SolidGeometry,
        "hollow": HollowGeometry,
        "freeform": FreeFormGeometry,
        "overhang": OverhangGeometry,
        "topology": TopologyMutationGeometry,
    }
    if category not in table:
        raise ValueError(f"unknown category {category}; choose from {list(table)}")
    return table[category](rng)


ALL_CATEGORIES = ["solid", "hollow", "freeform", "overhang", "topology"]
