"""EG-SAC agent: maximum-entropy off-policy optimization (Eqs. 28-33)."""
import copy
import numpy as np
import torch
import torch.nn.functional as F

from config import TRAIN, STATE_DIM, ACTION_DIM
from networks import GaussianActor, QCritic
from replay_buffer import ReplayBuffer


class SACAgent:
    name = "EG-SAC"

    def __init__(self, cfg=TRAIN, state_dim=STATE_DIM, action_dim=ACTION_DIM):
        self.cfg = cfg
        self.device = torch.device(cfg.device)
        self.actor = GaussianActor(state_dim, action_dim, cfg.hidden_dim).to(self.device)
        self.q1 = QCritic(state_dim, action_dim, cfg.hidden_dim).to(self.device)
        self.q2 = QCritic(state_dim, action_dim, cfg.hidden_dim).to(self.device)
        self.q1_t = copy.deepcopy(self.q1)
        self.q2_t = copy.deepcopy(self.q2)
        for p in self.q1_t.parameters():
            p.requires_grad_(False)
        for p in self.q2_t.parameters():
            p.requires_grad_(False)
        self.actor_opt = torch.optim.Adam(self.actor.parameters(), lr=cfg.actor_lr)
        self.q_opt = torch.optim.Adam(list(self.q1.parameters()) + list(self.q2.parameters()),
                                      lr=cfg.critic_lr)
        self.log_alpha = torch.tensor(np.log(cfg.init_alpha), device=self.device, requires_grad=True)
        self.alpha_opt = torch.optim.Adam([self.log_alpha], lr=cfg.alpha_lr)
        self.target_entropy = cfg.target_entropy
        self.buffer = ReplayBuffer(cfg.replay_capacity, state_dim, action_dim, cfg.device)

    @property
    def alpha(self):
        return self.log_alpha.exp()

    def store(self, s, a, r, ns, d):
        self.buffer.add(s, np.array([a], dtype=np.float32), r, ns, d)

    def act(self, state, deterministic=False):
        s = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            if deterministic:
                a = self.actor.deterministic(s)
            else:
                a, _ = self.actor.sample(s)
        return float(a.item())

    def update(self):
        s, a, r, ns, d = self.buffer.sample(self.cfg.batch_size)
        with torch.no_grad():
            a_next, logp_next = self.actor.sample(ns)
            q_target = torch.min(self.q1_t(ns, a_next), self.q2_t(ns, a_next))
            q_target = q_target - self.alpha.detach() * logp_next
            y = r + self.cfg.gamma * (1.0 - d) * q_target          # Eq. (29)
        q_loss = F.mse_loss(self.q1(s, a), y) + F.mse_loss(self.q2(s, a), y)  # Eq. (30)
        self.q_opt.zero_grad()
        q_loss.backward()
        self.q_opt.step()

        a_pi, logp_pi = self.actor.sample(s)
        q_pi = torch.min(self.q1(s, a_pi), self.q2(s, a_pi))
        actor_loss = (self.alpha.detach() * logp_pi - q_pi).mean()             # Eq. (31)
        self.actor_opt.zero_grad()
        actor_loss.backward()
        self.actor_opt.step()

        alpha_loss = -(self.log_alpha * (logp_pi.detach() + self.target_entropy)).mean()  # Eq. (32)
        self.alpha_opt.zero_grad()
        alpha_loss.backward()
        self.alpha_opt.step()

        with torch.no_grad():                                                  # Eq. (33)
            tau = self.cfg.tau
            for p, pt in zip(self.q1.parameters(), self.q1_t.parameters()):
                pt.mul_(1.0 - tau).add_(tau * p)
            for p, pt in zip(self.q2.parameters(), self.q2_t.parameters()):
                pt.mul_(1.0 - tau).add_(tau * p)
        return {"q_loss": float(q_loss.item()), "actor_loss": float(actor_loss.item()),
                "alpha": float(self.alpha.item())}

    def save(self, path: str):
        torch.save({"actor": self.actor.state_dict(), "q1": self.q1.state_dict(),
                    "q2": self.q2.state_dict(), "log_alpha": self.log_alpha.item()}, path)

    def load(self, path: str):
        ckpt = torch.load(path, map_location=self.device)
        self.actor.load_state_dict(ckpt["actor"])
        self.q1.load_state_dict(ckpt["q1"])
        self.q2.load_state_dict(ckpt["q2"])
