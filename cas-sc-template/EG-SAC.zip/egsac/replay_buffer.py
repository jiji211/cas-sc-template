"""Fixed-size off-policy replay buffer storing transitions (s, h, r, s', d)."""
import numpy as np
import torch


class ReplayBuffer:
    def __init__(self, capacity: int, state_dim: int, action_dim: int, device: str):
        self.capacity = capacity
        self.device = device
        self.s = np.zeros((capacity, state_dim), dtype=np.float32)
        self.a = np.zeros((capacity, action_dim), dtype=np.float32)
        self.r = np.zeros(capacity, dtype=np.float32)
        self.ns = np.zeros((capacity, state_dim), dtype=np.float32)
        self.d = np.zeros(capacity, dtype=np.float32)
        self.ptr = 0
        self.size = 0

    def add(self, s, a, r, ns, d):
        i = self.ptr
        self.s[i], self.a[i], self.r[i], self.ns[i], self.d[i] = s, a, r, ns, d
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int):
        idx = np.random.randint(0, self.size, size=batch_size)
        t = lambda x: torch.as_tensor(x[idx], device=self.device)
        return t(self.s), t(self.a), t(self.r), t(self.ns), t(self.d)

    def __len__(self):
        return self.size
